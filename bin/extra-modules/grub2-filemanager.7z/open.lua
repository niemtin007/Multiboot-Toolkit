hotkey = "f6" 
command = "configfile $prefix/main.cfg"
grub.add_hidden_menu (hotkey, command, "return")
