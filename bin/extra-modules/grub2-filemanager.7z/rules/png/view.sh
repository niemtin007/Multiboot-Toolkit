background_image "${grubfm_file}";
echo -n "Press [ESC] to continue...";
getkey;
background_image ${prefix}/themes/slack/black.png
