export theme=${prefix}/themes/slack/theme.txt;
configfile "(${grubfm_device})${grubfm_dir}${grubfm_filename}.grubfm";
