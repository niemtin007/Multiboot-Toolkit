echo "Path: ${grubfm_file}";
cat "${grubfm_file}";
getkey;
