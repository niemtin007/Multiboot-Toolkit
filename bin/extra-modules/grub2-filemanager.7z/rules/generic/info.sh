source ${prefix}/func.sh;

echo "[File]";
echo "grubfm_file: ${grubfm_file}";
echo "grubfm_path: ${grubfm_path}";
echo "grubfm_dir: ${grubfm_dir}";
echo "grubfm_device: ${grubfm_device}";
echo "grubfm_disk: ${grubfm_disk}";
echo "grubfm_name: ${grubfm_name}";
echo "grubfm_filename: ${grubfm_filename}";
echo "grubfm_fileext: ${grubfm_fileext}";
getkey;
