linux16 ${prefix}/ipxe.lkrn;
initrd16 "${grubfm_file}";
