efiload "${grubfm_file}";
echo "Press any key to continue ..";
getkey;
