chainloader -b -t "${grubfm_file}";
