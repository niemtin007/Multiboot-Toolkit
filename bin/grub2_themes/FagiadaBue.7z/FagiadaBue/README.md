# FagiadaBue
Grub 2 theme

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details at http://www.gnu.org/licenses

Grub Min Version: 198

The resolution the theme was designed to show best at, 640x480, 1024x768 etc,
or "any" for any resolution (resolution independent).

#Install
###chmod +x install.sh
###sudo ./install.sh
