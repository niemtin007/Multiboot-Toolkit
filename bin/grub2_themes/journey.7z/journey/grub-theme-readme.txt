grub-theme-readme.txt for the Debian Grub 2 theme "The Journey".
Written by: uhansen@debianart.org, 18.03.2012
--------------------------------

File: 
journey-grub-theme.tar.gz

This archive contains the GRUB2 theme files of the Debian GNU/Linux theme.

License: GNU GPL version 2 or (at your option) any later version.
A copy of the GNU GPL v2 can be found here:
http://www.gnu.org/licenses/gpl-2.0.html

--------------------------------

To install this theme on your computer:

1) If it doesn't exist yet, make a directory "themes" in /boot/grub.
sudo mkdir /boot/grub/themes

2) Unzip the archive
tar -xzvf journey-grub-theme.tar.gz

3) Copy the folder "journey" to
/boot/grub/themes/journey

4) Edit the GRUB2 configuration file /etc/default/grub to include these lines:

GRUB_GFXMODE=800x600
GRUB_THEME=/boot/grub/themes/journey/theme.txt

A resolution of 800x600px should be OK for most modern screens. 
But you are free to adapt it to the resolution of your own monitor. 
Valid resolutions for Grub can be found if you type "c" at the 
Grub boot menu and type "vbeinfo". 

5) Update GRUB2
sudo update-grub

That's it. Reboot.

--------------------------------

See more about this GRUB2 theme in the file
/boot/grub/themes/journey/theme.txt. 

More about my "Journey" theme for Debian can be found at:
http://http://wiki.debian.org/DebianArt/Themes/journey.

To learn more about GRUB2 themes see this excellent guide, which 
can be downloaded from this site:
http://www.4shared.com/file/lFCl6wxL/grub_guidetar.html

The author of the guide can be found here:
http://ubuntuforums.org/showthread.php?t=1823915

In this theme I used some elements from an Ubuntu theme 
created by Jo Shields:
http://retro.apebox.org/grubthemes/

Thanks Jo!


